Vertex 1  -1 -1 -1
Vertex 2  1 1 -1
Vertex 3  1 -1 1
Vertex 4  -1 1 1
Face 1  2 3 4
Face 2  2 1 3
Face 3  4 3 1
Face 4  1 2 4
