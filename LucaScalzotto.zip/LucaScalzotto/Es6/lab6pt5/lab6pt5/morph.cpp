#include "common.h"

GLuint program;
GLint timeParam;
GLint vertices_two_location;
GLint colors_two_location;

// Quadrato
GLint vertices_two_location2;
GLint colors_two_location2;

const GLfloat vertices_one[3][2] = {{0.0, 0.0}, {0.5,1.0}, {1.0, 0.0}};
const GLfloat vertices_two[3][2] = {{0.0, 1.0}, {0.5,0.0}, {1.0, 1.0}};
const GLfloat colors_two[3][3] = {{1, 1, 0}, {0, 1, 0}, {1, 0, 1}};

// Quadrato
const GLfloat vertices_one2[4][2] = {{0.0, 0.0}, {0.0, 1.0}, {1.0, 1.0}, {1.0, 0.0}};
const GLfloat vertices_two2[4][2] = {{0.0, 1.0}, {0.0, 0.0}, {1.0, 0.0}, {1.0, 1.0}};
const GLfloat colors_two2[4][3] = {{1, 1, 0}, {0, 1, 0}, {1, 0, 1}, {0, 0, 0}};

static void init()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glColor3f(0.0,0.0,0.0);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0,1.0,0.0,1.0);

    glEnable(GL_DEPTH_TEST);

    program = initShader("/Users/luca.scalzotto/Desktop/lab6pt5/lab6pt5/v.glsl",
                         "/Users/luca.scalzotto/Desktop/lab6pt5/lab6pt5/f.glsl");

    // Setup uniform and attribute prameters
    timeParam = glGetUniformLocation(program, "time");
    vertices_two_location = glGetAttribLocation(program, "vertices2");
	/* ----------- ADD ------------------ 
        handle additional variables if needed
	*/
    colors_two_location = glGetAttribLocation(program, "colors2");
    
    // Quadrato
    vertices_two_location2 = glGetAttribLocation(program, "vertices22");
    colors_two_location2 = glGetAttribLocation(program, "colors22");
}

static void draw(void)
{
    /* send elapsed time to shaders */
    glUniform1f(timeParam, glutGet(GLUT_ELAPSED_TIME));

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
//    glBegin(GL_TRIANGLES);
//        /* ----------- ADD ------------------
//            instead of lines, draw a triangle
//            assign color to the vertices
//        */
//        glVertexAttrib3fv(vertices_two_location, &vertices_two[0][0]);
//        glVertexAttrib3fv(colors_two_location, &colors_two[0][0]);
//        glColor3f(1, 0, 0);
//        glVertex2fv(vertices_one[0]);
//
//        glVertexAttrib3fv(vertices_two_location, &vertices_two[1][0]);
//        glVertexAttrib3fv(colors_two_location, &colors_two[1][0]);
//        glColor3f(0, 1, 0);
//        glVertex2fv(vertices_one[1]);
//
//        glVertexAttrib3fv(vertices_two_location, &vertices_two[2][0]);
//        glVertexAttrib3fv(colors_two_location, &colors_two[2][0]);
//        glColor3f(0, 0, 1);
//        glVertex2fv(vertices_one[2]);
//    glEnd();
    
    glBegin(GL_QUADS);
    /* ----------- ADD ------------------
     instead of lines, draw a triangle
     assign color to the vertices
     */
    glVertexAttrib3fv(vertices_two_location2, &vertices_two2[0][0]);
    glVertexAttrib3fv(colors_two_location2, &colors_two2[0][0]);
    glColor3f(1, 0, 0);
    glVertex2fv(vertices_one2[0]);
    
    glVertexAttrib3fv(vertices_two_location2, &vertices_two2[1][0]);
    glVertexAttrib3fv(colors_two_location2, &colors_two2[1][0]);
    glColor3f(0, 1, 0);
    glVertex2fv(vertices_one2[1]);
    
    glVertexAttrib3fv(vertices_two_location2, &vertices_two2[2][0]);
    glVertexAttrib3fv(colors_two_location2, &colors_two2[2][0]);
    glColor3f(0, 0, 1);
    glVertex2fv(vertices_one2[2]);
    
    glVertexAttrib3fv(vertices_two_location2, &vertices_two2[3][0]);
    glVertexAttrib3fv(colors_two_location2, &colors_two2[3][0]);
    glColor3f(1, 1, 1);
    glVertex2fv(vertices_one2[3]);
    glEnd();

    glutSwapBuffers();
    glutPostRedisplay();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(512, 512);
    glutCreateWindow("Simple GLSL example");
    glutDisplayFunc(draw);
    glutKeyboardFunc(commonKeyboard);

    init();

    glutMainLoop();
    return 0;
}
